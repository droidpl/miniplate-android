package com.mobgen.android.interview.kotlin.debug

import android.content.Context

/**
 * Created by j.de.pedro.lopez on 5/23/17.
 */
class DebugConfiguration {
    companion object {
        fun initialize(context: Context) {
            //Do nothing, this is a release config
        }
    }
}