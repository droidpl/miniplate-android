package com.nl.nuon.android.futurestreet

import android.app.Application
import com.nl.nuon.android.futurestreet.debug.DebugConfiguration
import com.nl.nuon.android.futurestreet.sdk.dependencies.NuonApi

/**
 * Created by j.de.pedro.lopez on 5/23/17.
 */
class NuonApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        DebugConfiguration.initialize(this)
        applicationApi = NuonApi.create(this, BuildConfig.API_ENDPOINT)
    }

    companion object {
        lateinit var applicationApi: NuonApi
        fun api(): NuonApi = applicationApi
    }
}