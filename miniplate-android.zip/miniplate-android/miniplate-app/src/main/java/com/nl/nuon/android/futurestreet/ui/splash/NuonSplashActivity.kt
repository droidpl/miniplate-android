package com.nl.nuon.android.futurestreet.ui.splash

import com.nl.nuon.android.futurestreet.base.MobgenPresenterActivity

/**
 * Created by j.de.pedro.lopez on 8/21/17.
 */
class NuonSplashActivity: MobgenPresenterActivity<NuonSplashPresenter>(), NuonSplashViewTranslator {

    override fun createPresenter(): NuonSplashPresenter = NuonSplashPresenter(this)
}