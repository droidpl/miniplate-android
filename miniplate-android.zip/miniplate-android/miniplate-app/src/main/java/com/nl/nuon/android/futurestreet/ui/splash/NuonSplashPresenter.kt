package com.nl.nuon.android.futurestreet.ui.splash

import com.nl.nuon.android.futurestreet.base.IMobgenViewTranslator
import com.nl.nuon.android.futurestreet.base.MobgenPresenter
import java.lang.ref.WeakReference

/**
 * Created by j.de.pedro.lopez on 8/21/17.
 */
class NuonSplashPresenter(view: NuonSplashViewTranslator): MobgenPresenter<NuonSplashViewTranslator>(WeakReference(view)) {

    override fun onReady() {
        super.onReady()
    }
}

interface NuonSplashViewTranslator: IMobgenViewTranslator {

}