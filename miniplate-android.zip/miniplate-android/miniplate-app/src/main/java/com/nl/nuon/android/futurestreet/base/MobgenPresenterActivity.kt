package com.nl.nuon.android.futurestreet.base

import android.arch.lifecycle.LifecycleRegistry
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity

/**
 * Base activity that supports MVP.
 */
abstract class MobgenPresenterActivity<out T : IMobgenPresenter> : AppCompatActivity(), IMobgenViewTranslator {

    /**
     * The current presenter.
     */
    private var presenter: T? = null

    private lateinit var registryOwner: LifecycleRegistry

    /**
     * Method that must provide a presenter item.

     * @return The presenter provided.
     */
    protected abstract fun createPresenter(): T?

    /**
     * Provides the presenter.

     * @return The presenter provided.
     */
    fun presenter(): T? = presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registryOwner = LifecycleRegistry(this)
        presenter = createPresenter()
        presenter?.onCreate(savedInstanceState, intent.extras)
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        presenter?.onReady()
    }

    override fun onPause() {
        super.onPause()
        presenter?.onPause()
    }

    override fun onResume() {
        super.onResume()
        presenter?.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter?.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        presenter?.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        presenter?.onRestoreInstanceState(savedInstanceState)
    }

    override fun context(): Context = applicationContext

    override fun resources(): Resources = resources

    override fun showErrorString(error: String) {
        Snackbar.make(findViewById(android.R.id.content), error, Snackbar.LENGTH_LONG).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        presenter?.onActivityResult(requestCode, resultCode, data)
    }

    override fun getLifecycle(): LifecycleRegistry = registryOwner
}
