package com.nl.nuon.android.futurestreet.debug

import android.app.Application
import com.facebook.stetho.Stetho
import com.squareup.leakcanary.LeakCanary

/**
 * Created by j.de.pedro.lopez on 5/23/17.
 */
class DebugConfiguration {
    companion object {
        fun initialize(app: Application) {
            Stetho.initialize(Stetho.newInitializerBuilder(app)
                    .enableDumpapp(Stetho.defaultDumperPluginsProvider(app))
                    .enableWebKitInspector(Stetho.defaultInspectorModulesProvider(app))
                    .build())
            LeakCanary.install(app)
        }
    }
}