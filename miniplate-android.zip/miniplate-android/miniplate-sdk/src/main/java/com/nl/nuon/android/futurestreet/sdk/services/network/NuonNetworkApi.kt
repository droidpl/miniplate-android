package com.nl.nuon.android.futurestreet.sdk.services.network

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */
interface NuonNetworkApi {

}