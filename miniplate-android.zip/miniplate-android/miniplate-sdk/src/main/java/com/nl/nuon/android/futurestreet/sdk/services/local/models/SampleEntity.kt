package com.nl.nuon.android.futurestreet.sdk.services.local.models

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

/**
 * Created by j.de.pedro.lopez on 8/21/17.
 */
@Entity
data class SampleEntity(
        @PrimaryKey val id: String
)