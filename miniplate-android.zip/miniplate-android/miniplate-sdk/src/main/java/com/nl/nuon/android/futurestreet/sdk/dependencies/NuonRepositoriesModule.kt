package com.nl.nuon.android.futurestreet.sdk.dependencies

import dagger.Module

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */

@Module
class NuonRepositoriesModule {

}