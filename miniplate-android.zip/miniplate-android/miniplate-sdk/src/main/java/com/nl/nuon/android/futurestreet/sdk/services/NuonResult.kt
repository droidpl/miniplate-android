package com.nl.nuon.android.futurestreet.sdk.services

import android.support.annotation.IntDef


/**
 * Created by j.de.pedro.lopez on 5/29/17.
 */

sealed class NuonResult

data class Loading(val resourceName: String? = null): NuonResult()

data class Error(val exception: Exception, val errorType: String? = null): NuonResult()

data class Data<out T>(val data: T, @Status.DataStatus val status: Int): NuonResult()

data class Status(@DataStatus val status: Int) {

    @IntDef(STATUS_FRESH.toLong(), STATUS_LOCAL.toLong(), STATUS_INCONSISTENT.toLong())
    @Retention(AnnotationRetention.SOURCE)
    annotation class DataStatus

    companion object {
        /**
         * The status of the request is fresh.
         */
        const val STATUS_FRESH = 0
        /**
         * The status of the data is dataLocal.
         */
        const val STATUS_LOCAL = 1
        /**
         * The status of the data is not consistent. This means an error
         * was produced when we tried to reach the dataLocal storage.
         */
        const val STATUS_INCONSISTENT = 2
    }
}