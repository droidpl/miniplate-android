package com.nl.nuon.android.futurestreet.sdk.utils

import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */
class Utils {

    companion object {
        internal val dateFormat = lazy({ SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss", Locale.getDefault()) })

        fun fromStringToDate(date: String): Date {
            return dateFormat.value.parse(date)
        }
    }
}