package com.nl.nuon.android.futurestreet.sdk.dependencies

import com.nl.nuon.android.futurestreet.sdk.services.network.NuonNetworkApi
import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */
@Module
class NuonNetworkModule(val baseUrl: String) {

    @Provides
    @Singleton
    fun providesRetrofit(): Retrofit{
        return Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(baseUrl)
                .build()
    }

    @Provides
    fun providesNetworkApi(retrofit: Retrofit): NuonNetworkApi {
        return retrofit.create(NuonNetworkApi::class.java)
    }
}