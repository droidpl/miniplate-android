package com.nl.nuon.android.futurestreet.sdk.services.local

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase
import android.arch.persistence.room.TypeConverters
import com.nl.nuon.android.futurestreet.sdk.services.local.converters.StringListTypeConverter
import com.nl.nuon.android.futurestreet.sdk.services.local.models.SampleEntity

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */
@Database(entities = arrayOf(SampleEntity::class), version = 1, exportSchema = false)
@TypeConverters(StringListTypeConverter::class)
abstract class NuonDatabase : RoomDatabase() {
}