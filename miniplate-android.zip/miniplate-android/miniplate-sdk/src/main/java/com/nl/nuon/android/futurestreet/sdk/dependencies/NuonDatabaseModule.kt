package com.nl.nuon.android.futurestreet.sdk.dependencies

import android.arch.persistence.room.Room
import android.content.Context
import com.nl.nuon.android.futurestreet.sdk.services.local.NuonDatabase
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */
@Module
class NuonDatabaseModule {

    val DATABASE_NAME = "nuon_database"

    @Provides
    @Singleton
    fun providesNuonDatabase(context: Context): NuonDatabase {
        return Room.databaseBuilder(context, NuonDatabase::class.java, DATABASE_NAME) //We will not add migration by this time
                .build()
    }
}