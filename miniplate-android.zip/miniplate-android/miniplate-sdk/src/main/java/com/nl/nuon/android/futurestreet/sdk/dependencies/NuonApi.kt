package com.nl.nuon.android.futurestreet.sdk.dependencies

import android.content.Context
import dagger.Component
import javax.inject.Singleton

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */

@Singleton
@Component(
        modules = arrayOf(
                ApplicationModule::class,
                NuonNetworkModule::class,
                NuonDatabaseModule::class,
                NuonRepositoriesModule::class
        )
)
interface NuonApi {

    fun networkApi(): NuonApi

    companion object {
        fun create(context: Context, url: String): NuonApi {
            return DaggerNuonApi.builder()
                    .applicationModule(ApplicationModule(context))
                    .nuonNetworkModule(NuonNetworkModule(url))
                    .build()
        }
    }
}