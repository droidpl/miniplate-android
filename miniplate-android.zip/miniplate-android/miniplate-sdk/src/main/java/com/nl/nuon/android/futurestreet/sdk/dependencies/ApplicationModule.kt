package com.nl.nuon.android.futurestreet.sdk.dependencies

import android.content.Context
import dagger.Module
import dagger.Provides

/**
 * Created by j.de.pedro.lopez on 5/26/17.
 */
@Module
class ApplicationModule(val context: Context) {

    @Provides
    fun providesContext(): Context{
        return context
    }
}